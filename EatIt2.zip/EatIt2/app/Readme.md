# google-eervice.json


I removed my google-servicr.json fire for security reasons

you can get your file while configuration your firebase app paste it in this folder
