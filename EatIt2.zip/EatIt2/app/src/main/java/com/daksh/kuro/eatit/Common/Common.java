package com.daksh.kuro.eatit.Common;

import com.daksh.kuro.eatit.Model.User;

public class Common {
    public static User currentUser;

}
